#include <iostream>
#include <string>
#include<project2.hpp>




int main(){

std::cout<<"Templete MAX "<< lib::max(10.02,20,500,70,80,600,1000.03)<<"\n";

std::cout<<"Templete MIN "<< lib::min(10.02,20,500,70,80,600,790,4.09)<<"\n";

std::cout<<"Templete SUB "<< lib::sub(10.02,20,90,70,995.55)<<"\n";
}